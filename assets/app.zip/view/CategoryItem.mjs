class CategoryItem extends ViewDoc {
    prop title = null;
    
    fun initView() {
        this.title = this.itemByID(ViewGroup, "category_title");
    }
    
    fun setTitle(text) {
        this.title.setText(text);
    }
}